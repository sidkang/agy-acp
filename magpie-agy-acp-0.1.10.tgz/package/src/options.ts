import type { ProviderOptionsState } from "./types";

export const PROVIDER_ID = "agy-acp";

export interface MagpieOptionSchema {
  key: string;
  label: string;
  description: string;
  default: boolean;
  placement?: "top";
  labels?: Record<string, string>;
  descriptions?: Record<string, string>;
  confirm?: string;
  confirms?: Record<string, string>;
}

/** One provider option: its schema text, env override, and state key. */
interface ProviderOptionSpec {
  /** Magpie / `package.json` option key, also passed to the live `option()` hook. */
  key: string;
  /** The field this option lands on in `ProviderOptionsState`. */
  stateKey: keyof ProviderOptionsState;
  envName: string;
  fallback: boolean;
  label: string;
  description: string;
  labels?: Record<string, string>;
  descriptions?: Record<string, string>;
}

function envBool(name: string): boolean | undefined {
  const raw = process.env[name]?.trim().toLowerCase();
  if (raw === "1" || raw === "true" || raw === "yes" || raw === "on") return true;
  if (raw === "0" || raw === "false" || raw === "no" || raw === "off") return false;
  return undefined;
}

function initialDefault(
  key: string,
  envName: string,
  pkgOptions: Record<string, unknown> | undefined,
  fallback: boolean,
): boolean {
  if (pkgOptions && typeof pkgOptions[key] === "boolean") {
    return pkgOptions[key] as boolean;
  }
  const fromEnv = envBool(envName);
  if (typeof fromEnv === "boolean") return fromEnv;
  return fallback;
}

/**
 * The single source of truth for provider options: schema keys, env override
 * names, fallbacks, and the `ProviderOptionsState` field each one feeds.
 */
const OPTION_SPECS: readonly ProviderOptionSpec[] = [
  {
    key: "quota_routing",
    stateKey: "quotaRouting",
    envName: "AGY_MAGPIE_QUOTA_ROUTING",
    fallback: true,
    label: "Quota-aware multi-account routing",
    description:
      "Gate exhausted 5-hour/weekly model buckets so Magpie routes new turns to other signed-in accounts.",
    labels: {
      zh: "按配额自动多账号路由",
    },
    descriptions: {
      zh: "当某个账号的 5 小时或周配额耗尽时，让 Magpie 自动将后续请求路由到其他已登录账号。",
    },
  },
  {
    key: "account_failover",
    stateKey: "accountFailover",
    envName: "AGY_MAGPIE_ACCOUNT_FAILOVER",
    // Off by default. Magpie follows a `401`, `402`, `403` or `429` to the next
    // account of this provider, so one failed turn becomes a request from every
    // account in the pool — and the vendor's terms call automating account rotation
    // unsupported. Off, the failure comes back to you and you pick the account.
    fallback: false,
    label: "Switch accounts automatically after a failure",
    description:
      "Off by default. When off, a turn that fails on this account's quota, sign-in or policy returns its own error and nothing is tried on your behalf. Turn it on and Magpie may answer the same turn from another signed-in account — which the vendor's terms treat as automating account rotation.",
    labels: {
      zh: "失败后自动切换账号",
    },
    descriptions: {
      zh: "默认关闭。关闭时，配额、登录或策略导致的失败会原样返回，不会代你尝试其它账号。开启后 Magpie 可能用另一个已登录账号重答同一请求——厂商条款把自动轮换账号视为不受支持。",
    },
  },
  {
    key: "cloak_prompts",
    stateKey: "cloakPrompts",
    envName: "AGY_MAGPIE_CLOAK_PROMPTS",
    // Off by default: the rewording is a workaround for a vendor check, not a
    // formatting preference, and the vendor's terms treat workarounds of that kind
    // as circumvention. Detection of the refusal is unaffected by this switch.
    fallback: false,
    label: "Reword third-party harness trigger lines",
    description:
      "Off by default. Rewords system-prompt lines that identify a third-party harness and are answered with a spent-quota refusal, so the same request goes through. This works around a vendor check; leave it off unless you accept that.",
    labels: {
      zh: "改写第三方客户端标识句（默认关）",
    },
    descriptions: {
      zh: "默认关闭。改写会被上游以配额耗尽为由拒答的第三方客户端标识句，使同一请求通过。这是绕过上游检查，除非你接受该风险，否则保持关闭。",
    },
  },
  {
    key: "minimal_agent",
    stateKey: "minimalAgent",
    envName: "AGY_MAGPIE_MINIMAL_AGENT",
    fallback: false,
    label: "Minimal agent system prompt",
    description:
      "Set excludeDefaultComponents on the bridge agent to trim ~1.6K native prompt tokens (1,991 -> 389); requests look slightly less like default agy CLI.",
    labels: {
      zh: "精简内置系统提示词",
    },
    descriptions: {
      zh: "开启 excludeDefaultComponents 可再省约 1.6K 内置提示词 Token（从 1,991 降至 389），但上游请求形态与默认 agy 略有差异。",
    },
  },
  {
    key: "expose_thinking",
    stateKey: "exposeThinking",
    envName: "AGY_MAGPIE_EXPOSE_THINKING",
    fallback: true,
    label: "Expose thought summaries",
    description:
      "Stream Antigravity ACP thought summaries as Anthropic thinking blocks. agy signs none, so each block carries a UUID-shaped placeholder: clients keep it, and Magpie drops it before a Claude route.",
    labels: {
      zh: "输出思考摘要块",
    },
    descriptions: {
      zh: "将 Antigravity ACP 返回的思考摘要编码为 Anthropic thinking 内容块输出。",
    },
  },
];

export function buildProviderOptionSchemas(
  pkgOptions?: Record<string, unknown>,
): MagpieOptionSchema[] {
  return OPTION_SPECS.map((spec) => ({
    key: spec.key,
    label: spec.label,
    description: spec.description,
    default: initialDefault(spec.key, spec.envName, pkgOptions, spec.fallback),
    ...(spec.labels ? { labels: spec.labels } : {}),
    ...(spec.descriptions ? { descriptions: spec.descriptions } : {}),
  }));
}

/**
 * The caller's own `phrase=replacement` pairs for the cloaker.
 *
 * Kept out of `OPTION_SPECS` on purpose: Magpie renders those as switches, and this
 * is a string. It is read from the plugin options record (so it can be written by
 * hand) or from the environment when the record has none.
 */
function readSaidAs(pkgOptions?: Record<string, unknown>): string {
  const raw = pkgOptions?.cloak_said_as ?? process.env.AGY_MAGPIE_CLOAK_SAID_AS;
  return typeof raw === "string" ? raw.slice(0, 4096) : "";
}

export function readProviderOptions(
  pluginInput?: {
    magpie?: {
      option?: (provider: string, key: string) => boolean | undefined;
      options?: (provider: string) => Record<string, boolean> | undefined;
    };
  },
  pkgOptions?: Record<string, unknown>,
): ProviderOptionsState {
  const fromMagpie = pluginInput?.magpie?.options?.(PROVIDER_ID) ?? {};
  const state: ProviderOptionsState = {
    quotaRouting: false,
    cloakPrompts: false,
    minimalAgent: false,
    exposeThinking: false,
    cloakSaidAs: readSaidAs(pkgOptions),
    accountFailover: false,
  };

  for (const spec of OPTION_SPECS) {
    const live = pluginInput?.magpie?.option?.(PROVIDER_ID, spec.key);
    ((state as unknown) as Record<string, unknown>)[spec.stateKey] =
      typeof live === "boolean"
        ? live
        : typeof fromMagpie[spec.key] === "boolean"
          ? fromMagpie[spec.key]!
          : initialDefault(spec.key, spec.envName, pkgOptions, spec.fallback);
  }

  return state;
}
